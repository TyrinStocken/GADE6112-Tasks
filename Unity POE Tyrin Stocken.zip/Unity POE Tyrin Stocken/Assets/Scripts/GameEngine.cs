﻿using UnityEngine;

namespace MyRTSGame
{
    public class GameEngine : MonoBehaviour
    {
        private Map map = new Map();
        // Use this for initialization
        void Start()
        {
            Instantiate(Resources.Load("ResourceBuildingRed"), new Vector3(46, 10, -2), Quaternion.identity);
            Instantiate(Resources.Load("health 100"), new Vector3(46, 10, -3), Quaternion.identity);
            Instantiate(Resources.Load("ResourceBuildingBlue"), new Vector3(11, 10, -2), Quaternion.identity);
            Instantiate(Resources.Load("health 100"), new Vector3(11, 10, -3), Quaternion.identity);
            Instantiate(Resources.Load("FactoryBuildingRed"), new Vector3(11, 13, -2), Quaternion.identity);
            Instantiate(Resources.Load("health 100"), new Vector3(11, 13, -3), Quaternion.identity);
            Instantiate(Resources.Load("FactoryBuildingRed"), new Vector3(46, 13, -2), Quaternion.identity);
            Instantiate(Resources.Load("health 100"), new Vector3(46, 13, -3), Quaternion.identity);

            int xStart = 48;
            int yStart = 24;
            var tileSize = new Vector2(2, 2);

            for (int k = 0; k < 20; k++)
            {
                var yPos = k * tileSize.y - yStart;
                for (int i = 0; i < 20; i++)
                {
                    var xPos = -i * tileSize.x + xStart;
                    Instantiate(Resources.Load("grass"), new Vector3(xPos, yPos, 0), Quaternion.identity);
                }
            }
            map.fillMapWithMeleeUnits();
            map.fillMapWithRangedUnits();
            foreach (Unit temp in map.mU)
            {
                if (temp != null)
                {
                    var unitType = temp.GetType().ToString();
                    var xPos = temp.XPosition * tileSize.x - xStart;
                    var yPos = -temp.YPosition * tileSize.y + yStart;
                    if (unitType.Contains("Melee"))
                    {
                        if (temp.Faction.Equals("RED"))
                        {
                            Instantiate(Resources.Load("MeleeUnitRed"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("MeleeUnitBlue"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                    }
                    else
                    {
                        if (temp.Faction.Equals("RED"))
                        {
                            Instantiate(Resources.Load("RangedUnitRed"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("RangedUnitBlue"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                    }
                }
            }
        }

        // Update is called once per frame
        void Update()
        {
            int xStart = 48;
            int yStart = 24;
            var tileSize = new Vector2(2, 2);

            map.fillMapWithMeleeUnits();
            map.fillMapWithRangedUnits();
            foreach (MeleeUnit temp in map.mU)
            {
                if (temp != null)
                {
                    var unitType = temp.GetType().ToString();
                    var xPos = temp.XPosition * tileSize.x - xStart;
                    var yPos = -temp.YPosition * tileSize.y + yStart;
                    if (unitType.Contains("Melee"))
                    {
                        if (temp.Faction.Equals("RED"))
                        {
                            Instantiate(Resources.Load("MeleeUnitRed"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("MeleeUnitBlue"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                    }
                    else
                    {
                        if (temp.Faction.Equals("RED"))
                        {
                            Instantiate(Resources.Load("RangedUnitRed"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("RangedUnitBlue"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                            Instantiate(Resources.Load("health 100"), new Vector3(xPos, yPos, -3), Quaternion.identity);
                        }
                    }
                }
            }
        }
    }
}

